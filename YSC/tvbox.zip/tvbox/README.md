### 1. TVBox 开源版  
- TVBox1.0.0 ，[GitHub社区](https://github.com/CatVodTVOfficial/TVBoxOSC) 根据官方代码仓生成的安卓应用。  
- 移植了猫影视V6的内核，可以无缝对接电视直播、影视剧点播站源规则，就是说原来的接口可以直接用。  
- 本地功能，这个版本也具备了，只需要开启存储权限，在配置地址栏输入本地规则地址即可。  
- 设置——配置地址——输入你的站源规则——确定即可；  

2. 下载地址
[影视仓手机版软件下载地址](https://yingshicang.lanzoul.com/b04dr938f)
密码:ckfw  
[欢迎大家加群一起交流学习分享---点击直接加入群](https://qm.qq.com/cgi-bin/qm/qr?k=CdsCdFmE9qO5dROu-mT_4PANEsp_VbkH&jump_from=webapi&authKey=uHbpJc785kr8fTzzPeK+aGxB/A6XC6rzUq/s0vYl1hs6BfgASso1qd3Xm7/S5yHK) 

3.本接口已经完全支持本地化，可自行下载本地化工具,下载地址见2，找到根目录下tvbox目录，按里面jiaocheng.txt配置即可。

4.本地化接口会及时同步更新，需要的可用本地化工具删除源，从新下载即可，自动解压。
